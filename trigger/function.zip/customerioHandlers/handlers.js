

var Customerio = require('node-customer.io');
var cio = new Customerio('cd5e6728c57c525fa1de', 'c0defee79d2c3b33ebc6');

const AWS = require('aws-sdk');

export async function handleVoicemailsStream(record) {
    console.log(`Voicemail event: ${record.eventName}`);
    console.log('Full event:', JSON.stringify(record, null, 2));
    
    try {
        const allInfo = record.dynamodb.NewImage;
        const userId = allInfo.forwardedFrom.S;
        const voicemailTranscript = allInfo.voicemail_transcript.S;

        let createdAt = allInfo.date && allInfo.date.S
            ? allInfo.date.S
            : new Date().toISOString();

        console.log('User ID:', userId);
        console.log('Created At:', createdAt);
        console.log('voicemailTranscript:', voicemailTranscript);

        const webhookData = {
            userId: userId,
            createdTime: createdAt,
            voicemail_log: voicemailTranscript 
        };

        const trackResult = await new Promise((resolve, reject) => {
            cio.track(userId, 'voicemail_added', webhookData, function(err, res) {
                if (err) reject(err);
                else resolve(res);
            });
        });

        console.log('Customer.io track response:', {
            headers: trackResult.headers,
            statusCode: trackResult.statusCode
        });

    } catch (error) {
        console.error('Error in handleVoicemailsStream:', error);
        throw error; // Re-throw the error to be caught by the main handler
    }
}


export async function handleResellersStream(record) {
    console.log(`Resellers event: ${record.eventName}`);
    console.log('All row data:', JSON.stringify(record.dynamodb.NewImage || record.dynamodb.OldImage));
    console.log("This is all records", record)
    
    const allInfo = record.dynamodb.NewImage;
    const userId = allInfo['email_address']['S'];
    const emailAddress = allInfo['email_address']['S'];
    let createdAt;

    if (allInfo['timestamp'] && allInfo['timestamp']['S']) {
        const isoDateTime = allInfo['timestamp']['S'];
        const date = new Date(isoDateTime);
        createdAt = Math.floor(date.getTime() / 1000); // Convert to Unix timestamp in seconds
    } else {
        createdAt = Math.floor(Date.now() / 1000); // Current time in seconds
    }

    console.log('User ID:', userId);
    console.log('Email:', emailAddress);
    console.log('Created At:', createdAt);

    const customerData = {
        ...Object.entries(allInfo).reduce((acc, [key, value]) => {
            acc[key] = value.S || value.N || value.BOOL;
            return acc;
        }, {}),
        created_at: createdAt,
        last_updated: Math.floor(Date.now() / 1000),
        type: "reseller"
    };

    console.log('Customer Data to be sent:', JSON.stringify(customerData, null, 2));

    try {
        const result = await new Promise((resolve, reject) => {
            cio.identify(userId, customerData, emailAddress, function(err, res) {
                if (err) reject(err);
                else resolve(res);
            });
        });

        console.log('Customer.io API Response:', {
            headers: result.headers,
            statusCode: result.statusCode
        });
    } catch (error) {
        console.error('Error calling Customer.io API:', error);
    }

    // Add your logic for resellers table here
}

export async function handleTextLogsStream(record) {
    console.log(`Text event: ${record.eventName}`);
    console.log('Full event:', JSON.stringify(record, null, 2));
    
    try {
        const allInfo = record.dynamodb.NewImage;
        const userId = allInfo.forwardedFrom.S;
        const textContent = allInfo.transcript.S;

        let createdAt = allInfo.date && allInfo.date.S
            ? allInfo.date.S
            : new Date().toISOString();

        console.log('User ID:', userId);
        console.log('Created At:', createdAt);
        console.log('Text Content:', textContent);

        const webhookData = {
            userId: userId,
            createdTime: createdAt,
            transcript: textContent 
        };

        const trackResult = await new Promise((resolve, reject) => {
            cio.track(userId, 'text_added', webhookData, function(err, res) {
                if (err) reject(err);
                else resolve(res);
            });
        });

        console.log('Customer.io track response:', {
            headers: trackResult.headers,
            statusCode: trackResult.statusCode
        });

    } catch (error) {
        console.error('Error in handleTextLogsStream:', error);
        throw error;
    }
}

export async function handleClientsStream(record) {
    console.log(`Clients event: ${record.eventName}`);
    const allInfo = record.dynamodb.NewImage;
    const userId = allInfo['number']['S'];
    const emailAddress = allInfo['email_address']['S'];
    const clientType = allInfo.reseller_email ? "reseller_subaccount" : "client"

    let createdAt;

    if (allInfo['created'] && allInfo['created']['S']) {
        const isoDateTime = allInfo['created']['S'];
        const date = new Date(isoDateTime);
        createdAt = Math.floor(date.getTime() / 1000); // Convert to Unix timestamp in seconds
    } else {
        createdAt = Math.floor(Date.now() / 1000); // Current time in seconds
    }

    console.log('User ID:', userId);
    console.log('Email:', emailAddress);
    console.log('Created At:', createdAt);


    let customerData
    if (clientType == "reseller_subaccount") {
        const reseller_email = allInfo.reseller_email
        //Trigger that reseller has added a subaccount
        await resellerAddedSubaccount(reseller_email)

        customerData = {
            ...Object.entries(allInfo).reduce((acc, [key, value]) => {
                acc[key] = value.S || value.N || value.BOOL;
                return acc;
            }, {}),
            created_at: createdAt,
            last_updated: Math.floor(Date.now() / 1000),
            type: clientType,
            reseller_email: allInfo.reseller_email
        };
        console.log('Reseller Subaccount to be sent:', JSON.stringify(customerData, null, 2));
    } else {
        customerData = {
            ...Object.entries(allInfo).reduce((acc, [key, value]) => {
                acc[key] = value.S || value.N || value.BOOL;
                return acc;
            }, {}),
            created_at: createdAt,
            last_updated: Math.floor(Date.now() / 1000),
            type: clientType
        };
        console.log('Client Data to be sent:', JSON.stringify(customerData, null, 2));
    }
    

    try {
        const result = await new Promise((resolve, reject) => {
            cio.identify(userId, customerData, emailAddress,function(err, res) {
                if (err) reject(err);
                else resolve(res);
            });
        });

        console.log('Customer.io API Response:', {
            headers: result.headers,
            statusCode: result.statusCode
        });
    } catch (error) {
        console.error('Error calling Customer.io API:', error);
    }
}

async function resellerAddedSubaccount(email_address) {
    const webhookData = {
        userId: email_address,
        createdTime: createdAt,
    };
    const trackResult = await new Promise((resolve, reject) => {
        cio.track(userId, 'reseller_subaccount_added', webhookData, function(err, res) {
            if (err) reject(err);
            else resolve(res);
        });
    });
    console.log('Customer.io track response:', {
        headers: trackResult.headers,
        statusCode: trackResult.statusCode
    });
}



    // Add your logic for clients table here


export async function handleCallLogsStream(record) {
    console.log(`Call log event: ${record.eventName}`);
    console.log('Full event:', JSON.stringify(record, null, 2));
    
    try {
        const allInfo = record.dynamodb.NewImage;
        const userId = allInfo.forwardedFrom.S;
        const callDetails = allInfo.transcript ? allInfo.transcript.S : 'No call details available';

        let createdAt = allInfo.date && allInfo.date.S
            ? allInfo.date.S
            : new Date().toISOString();

        console.log('User ID:', userId);
        console.log('Created At:', createdAt);
        console.log('Call Details:', callDetails);

        const webhookData = {
            userId: userId,
            createdTime: createdAt,
            call_log: callDetails 
        };

        const trackResult = await new Promise((resolve, reject) => {
            cio.track(userId, 'calllog_added', webhookData, function(err, res) {
                if (err) reject(err);
                else resolve(res);
            });
        });

        console.log('Customer.io track response:', {
            headers: trackResult.headers,
            statusCode: trackResult.statusCode
        });

    } catch (error) {
        console.error('Error in handleCallLogsStream:', error);
        throw error;
    }
}